import React, { useState } from "react";
import { useEffect } from "react";
import { makeStyles } from "@mui/styles";
import {
    TextField,
    Button,
    Box,
    Divider,
    Grid,
    Typography,
    Select,
    MenuItem,
    CircularProgress,
    DialogContent
} from "@mui/material";
import Navbar from './components/Navbar';
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";

import FormControl from "@mui/material/FormControl";
import { StyledEngineProvider, CssVarsProvider } from '@mui/joy/styles';
import { NavLink } from "react-router-dom";
// import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
// import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';

import { DesktopDatePicker } from '@mui/x-date-pickers/DesktopDatePicker';
import FormHelperText from '@mui/material/FormHelperText';
import AdapterDateFns from "@mui/lab/AdapterDateFns";
import LocalizationProvider from "@mui/lab/LocalizationProvider";
import InputLabel from "@mui/material/InputLabel";
import { styled } from '@mui/material/styles';
// import { useNavigate } from "react-router-dom";
import Paper from '@mui/material/Paper';
import Checkbox1 from "./components/Checkbox";
import { left } from "@popperjs/core";
import Autocomplete from '@mui/material/Autocomplete';
import { red } from "@mui/material/colors";

const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
    ...theme.typography.body2,
    padding: theme.spacing(1),
    textAlign: 'center',
    color: theme.palette.text.secondary,
}));

// const navigate = useNavigate();
export default function SimplePaper() {
    const [errors, setErrors] = useState({});
    const initialValues = { username: "",leader:"",member:"",title:"",statement:"",cause:"",solution:"",benefit:"",scope:"",section:""};
    const [formValues, setFormValues] = useState(initialValues);
    const [formErrors, setFormErrors] = useState({});

  
    const handleChange = (e) => {
      const { name, value } = e.target;
      setFormValues({ ...formValues, [name]: value });
    };
  
    const handleSubmit = () => {
        
        setFormErrors(validate(formValues));
        
    };
  
 



    useEffect(() => {
      console.log(formErrors);
   
        console.log(formValues);
      
    }, [formErrors]);




    const validate = (values) => {
      let errors = {}
      let error = errors
      setErrors(error);

      if (!values.section  ) {
        errors.section = " section is required!";
        setErrors(error)  
      }


      if (!values.username  ) {
        errors.username = " Name is required!";
        setErrors(error)  
      }
      if (!values.leader) {
        errors.leader = "Leader Name is required!";
        setErrors(error)
      }
      if (!values.member) {
        errors.member = "Member Name is required!";
        setErrors(error)
      }
      if (!values.title) {
        errors.title = "Title is required!";
        setErrors(error)
      }
      if (!values.statement) {
        errors.statement = "Statement is required!";
        setErrors(error)
      }
      if (!values.cause) {
        errors.cause = "Cause is required!";
        setErrors(error)
      }
      if (!values.solution) {
        errors.solution = "solution is required!";
        setErrors(error)
      }
      if (!values.benefit) {
        errors.benefit = "Benefits is required!";
        setErrors(error)
      }
      if (!values.scope) {
        errors.scope = "Scope is required!";
        setErrors(error)
      }
      return errors;
    };



    const Sbu = [
        { label: 'Operation'},
        { label: 'Mechanical Maintanencer' },
        { label: 'Electrical Maintanence' },
        { label: 'C&I Maintanence' },
        { label: 'Fdy PC' },
        { label: 'Room-1' },
        { label: 'Room-2' },

    ];
    const department = [
        { label: 'Operation' },
        { label: 'Mechanical Maintanencer' },
        { label: 'Electrical Maintanence' },
        { label: 'C&I Maintanence' },
        { label: 'Fdy PC' },
        { label: 'Room-1' },
        { label: 'Room-2' },

    ];
    const Section = [
        { label: 'Operation' ,id:"1"  },
        { label: 'Mechanical Maintanencer' ,id:"2"},
        { label: 'Electrical Maintanence',id:"3" },
        { label: 'C&I Maintanence',id:"4" },
        { label: 'Fdy PC' ,id:"5"},
        { label: 'Room-1',id:"6" },
        { label: 'Room-2',id:"7" },

    ];
    return (
        <>
            <Navbar name="Kaizen" />
            <Box sx={{ flexGrow: 1, mt: 7, pr: 7, pl: 7 }}>

                <Item>

                    {/* <Grid container justifyContent="center" xs={12} sm={12} md={12} lg={12} pb={1} >
                    <Grid item className='para1'>KAIZEN SUMMARY SHEET</Grid>
                </Grid> */}

                    {/* <Divider/> */}

                    <Grid container className="text1" xs={12} sm={12} md={12} lg={12}>

                        <Grid container={true} item={true} xs={12} sm={12} md={4} lg={4}>
                            <Grid item xs={12} sm={12} md={3} lg={3} mt={1}>
                                <Box>
                                    <Grid mt={2}>
                                        <InputLabel component="proglabel" justifyContent="center" style={{ fontWeight: "bold" }}>
                                            SBU<Typography component="span1"  > * </Typography>:
                                        </InputLabel>
                                    </Grid>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={12} md={8} lg={8} mt={1}>
                                <Box>
                                    <FormControl fullWidth>

                                        <Autocomplete
                                            disablePortal
                                            id="combo-box-demo"
                                            options={Sbu}
                                             
                                            renderInput={(params) => <TextField {...params} label="Select SBU" />}
                                        />
                                    </FormControl>
                                </Box>
                            </Grid>
                        </Grid>

                        <Grid container={true} item={true} xs={12} sm={12} md={4} lg={4}>
                            <Grid item xs={12} sm={12} md={3} lg={3} mt={1}>
                                <Box>
                                    <Grid mt={2}>
                                        <InputLabel component="proglabel" style={{ fontWeight: "bold" }} >
                                            Department<Typography component="span1"  > * </Typography>:
                                        </InputLabel>
                                    </Grid>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={12} md={8} lg={8} mt={1}>
                                <Box>
                                    <FormControl fullWidth>

                                        <Autocomplete
                                            disablePortal
                                            id="combo-box-demo"
                                            options={department}

                                            renderInput={(params) => <TextField {...params} label="Select Department" />}
                                        />
                                    </FormControl>
                                </Box>
                            </Grid>
                        </Grid>

                        <Grid container={true} item={true} xs={12} sm={12} md={4} lg={4}>
                            <Grid item xs={12} sm={12} md={3} lg={3} mt={1}>
                                <Box>
                                    <Grid mt={2}>
                                        <InputLabel component="proglabel" style={{ fontWeight: "bold" }} >
                                            Section/Area<Typography component="span1"  > * </Typography>:
                                        </InputLabel>
                                    </Grid>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={12} md={8} lg={8} mt={1}>
                                <Box>
                                    <FormControl fullWidth>

                                        <Autocomplete
                                            // disablePortal
                                            id="combo-box-demo"
                                            options={Section}
                                            name="section"
                                            value={formValues.section}
                                            onChange={handleChange}
                                            error={errors.section?true:false}
                                            renderInput={(params) => <TextField {...params} label="Select Section"   />}
                                        />
                                    </FormControl>
                                </Box>
                            </Grid>
                        </Grid>

                    </Grid>

                    <Grid container className="text1" xs={12} sm={12} md={12} lg={12}>

                        <Grid container={true} item={true} xs={12} sm={12} md={4} lg={4}>
                            <Grid item xs={12} sm={12} md={3} lg={3} mt={1}>
                                <Box>
                                    <Grid mt={1}>
                                        <InputLabel component="proglabel" justifyContent="center" style={{ fontWeight: "bold" }}>
                                            Team Name<Typography component="span1"  > * </Typography>:
                                        </InputLabel>
                                        {/* <FormHelperText style={{color:"red"}} sx={{m: 0, mt: 0.5, mb: 1}}>{formErrors.username}</FormHelperText> */}
                                   
                                    </Grid>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={12} md={8} lg={8} mt={1}>
                                <Box>
                                    <Grid>
                                    <TextField fullWidth id="outlined-basic" size="small"
                                            error={errors.username?true:false}
                                            value={formValues.username}
                                            name="username"
                                            
                                            onChange={handleChange}
                                            // onChange={setData("PROGRAM_NAME")}
                                           />
                                       

                                    </Grid>
                                </Box>
                            </Grid>
                        </Grid>

                        <Grid container={true} item={true} xs={12} sm={12} md={4} lg={4}>
                            <Grid item xs={12} sm={12} md={3} lg={3} mt={1}>
                                <Box>
                                    <Grid mt={1}>
                                        <InputLabel component="proglabel" style={{ fontWeight: "bold" }} >
                                            Team Leader<Typography component="span1"  > * </Typography>:
                                        </InputLabel>
                                        {/* <FormHelperText style={{color:"red"}} >{formErrors.leader}</FormHelperText> */}
                                  
                                    </Grid>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={12} md={8} lg={8} mt={1}>
                                <Box>
                                    <Grid>
                                        <TextField fullWidth id="outlined-basic" size="small"
                               value={formValues.leader}
                               name="leader"
                               error={errors["leader"]?true:false}
                               onChange={handleChange}
                               // onChange={setData("PROGRAM_NAME")}
                              />
                            </Grid>
                                </Box>
                            </Grid>
                        </Grid>

                        <Grid container={true} item={true} xs={12} sm={12} md={4} lg={4}>
                            <Grid item xs={12} sm={12} md={3} lg={3} mt={1}>
                                <Box>
                                    <Grid mt={1}>
                                        <InputLabel component="proglabel" style={{ fontWeight: "bold" }} >
                                            Team Member<Typography component="span1"  > * </Typography>:
                                        </InputLabel>
                                        {/* <FormHelperText style={{color:"red"}} sx={{m: 0, mt: 0.5, mb: 1}}>{formErrors.member}</FormHelperText>
                                   */}
                                    </Grid>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={12} md={8} lg={8} mt={1}>
                                <Box>
                                    <Grid>
                                        <TextField fullWidth id="outlined-basic" size="small"
                                      value={formValues.member}
                                      name="member"
                                      error={errors["member"]?true:false}
                                      onChange={handleChange}
                                      // onChange={setData("PROGRAM_NAME")}
                                     />
                                   </Grid>
                                </Box>
                            </Grid>
                        </Grid>

                    </Grid>

                    <Grid container xs={12} sm={12} md={12} lg={12} mt={1} d>
                        <Grid container={true} item={true} xs={12} sm={12} md={6} lg={6}>
                            <Grid item xs={12} sm={12} md={3} lg={3} mt={1}>
                                <Box>
                                    <InputLabel component="proglabel" style={{ fontWeight: "bold" }}>
                                        Start Date<Typography component="span1"  > * </Typography>:
                                    </InputLabel>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={12} md={9} lg={9} mt={1}>
                                <Box>
                                
            
           
                                </Box>
                            </Grid>
                        </Grid>


                        <Grid container={true} item={true} xs={12} sm={12} md={6} lg={6}>
                            <Grid item xs={12} sm={12} md={3} lg={3} mt={1}>
                                <Box>
                                    <InputLabel component="proglabel" style={{ fontWeight: "bold" }} >
                                        End Date<Typography component="span1"  > * </Typography>:
                                    </InputLabel>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={12} md={9} lg={9} mt={1}>
                                <Box>
                                    <FormControl fullWidth>


                                        <LocalizationProvider dateAdapter={AdapterDateFns}>

                                            <FormHelperText sx={{ m: 0, mt: 0.5, mb: 1 }}></FormHelperText>
                                        </LocalizationProvider>


                                    </FormControl>
                                </Box>
                            </Grid>
                        </Grid>
                    </Grid>

                    <Grid >

                        <StyledEngineProvider >
                            <CssVarsProvider>

                                <Checkbox1 />



                            </CssVarsProvider>
                        </StyledEngineProvider>

                    </Grid>




                    <Grid container={true} item={true} xs={12} sm={12} md={12} lg={12} mt={3}>
                        <Grid container mt={1}>
                            <Grid container={true} item={true} xs={12} sm={12} md={12} lg={12}
                            >
                                <Grid item xs={12} sm={12} md={3} lg={2.5} mt={1} textAlign="left">
                                    <Box>
                                        <InputLabel component="proglabel" style={{ fontWeight: "bold" }}>
                                            1. PROJECT TITLE<Typography component="span1"  > * </Typography>:
                                        </InputLabel>
                                        {/* <FormHelperText style={{color:"red"}} sx={{m: 0, mt: 0.5, mb: 1}}>{formErrors.title}</FormHelperText>
                                  */}
                                    </Box>
                                </Grid>
                                <Grid item xs={12} sm={12} md={8} lg={8}>
                                    <Box>
                                        <TextField fullWidth maxLength={100} size="small"
                                               value={formValues.title}
                                               name="title"
                                               error={errors["title"]?true:false}
                                               onChange={handleChange}
                                               // onChange={setData("PROGRAM_NAME")}
                                              />
                                             </Box>
                                </Grid>
                            </Grid>
                        </Grid>
                        <Grid container mt={1}>
                            <Grid container={true} item={true} xs={12} sm={12} md={12} lg={12}
                            >
                                <Grid item xs={12} sm={12} md={3} lg={2.5} mt={1} textAlign="left">
                                    <Box>
                                        <InputLabel component="proglabel" style={{ fontWeight: "bold" }} >
                                            2.PROBLEM STATEMENT<Typography component="span1"  > * </Typography>:
                                        </InputLabel>
                                        {/* <FormHelperText style={{color:"red"}} sx={{m: 0, mt: 0.5, mb: 1}}>{formErrors.statement}</FormHelperText>
                                    */}
                                    </Box>
                                </Grid>
                                <Grid item xs={12} sm={12} md={8} lg={8}>
                                    <Box>
                                        <TextField fullWidth maxLength={100} size="small"
                                             value={formValues.statement}
                                             name="statement"
                                             error={errors["statement"]?true:false}
                                             onChange={handleChange}
                                             // onChange={setData("PROGRAM_NAME")}
                                            />
                                         </Box>
                                </Grid>
                            </Grid>
                        </Grid>
                        <Grid container mt={1}>
                            <Grid container={true} item={true} xs={12} sm={12} md={12} lg={12}
                            >
                                <Grid item xs={12} sm={12} md={3} lg={2.5} mt={1} textAlign="left">
                                    <Box>
                                        <InputLabel component="proglabel" style={{ fontWeight: "bold" }}>
                                            3.ROOT CAUSE<Typography component="span1"  > * </Typography>:
                                        </InputLabel>
                                        {/* <FormHelperText style={{color:"red"}} sx={{m: 0, mt: 0.5, mb: 1}}>{formErrors.cause}</FormHelperText> */}
                                    </Box>
                                </Grid>
                                <Grid item xs={12} sm={12} md={8} lg={8}>
                                    <Box>
                                        <TextField fullWidth maxLength={100} size="small"
                           value={formValues.cause}
                           name="cause"
                           error={errors["cause"]?true:false}
                           onChange={handleChange}
                           // onChange={setData("PROGRAM_NAME")}
                          />
                      
                                    </Box>
                                </Grid>
                            </Grid>
                        </Grid>
                        <Grid container mt={1}>
                            <Grid container={true} item={true} xs={12} sm={12} md={12} lg={12}
                            >
                                <Grid item xs={12} sm={12} md={3} lg={2.5} mt={1} textAlign="left" >
                                    <Box>
                                        <InputLabel component="proglabel" style={{ fontWeight: "bold" }}>
                                            4. DEVELOPED SOLUTION<Typography component="span1"  > * </Typography>:
                                        </InputLabel>
                                        {/* <FormHelperText style={{color:"red"}} sx={{m: 0, mt: 0.5, mb: 1}}>{formErrors.solution}</FormHelperText> */}
                                    </Box>
                                </Grid>
                                <Grid item xs={12} sm={12} md={8} lg={8}>
                                    <Box>
                                        <TextField fullWidth maxLength={100} size="small"
                                            value={formValues.solution}
                                            name="solution"
                                            error={errors["solution"]?true:false}
                                            onChange={handleChange}
                                            // onChange={setData("PROGRAM_NAME")}
                                           />
                                        
                                    </Box>
                                </Grid>
                            </Grid>
                        </Grid>

                    </Grid>


                    <Grid container xs={12} sm={12} md={12} lg={12} mt={1} >
                        <Grid container={true} item={true} xs={12} sm={12} md={6} lg={6}>
                            <Grid item xs={12} sm={12} md={4} lg={3.5} mt={1.5} textAlign="left" mr={4.3}>
                                <Box>
                                    <InputLabel component="proglabel" style={{ fontWeight: "bold" }}>
                                        5. BEFORE PHOTO<Typography component="span1"  > * </Typography>:
                                    </InputLabel>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={12} md={3} lg={3} mt={1}>
                                <Box>

                                    <Button variant="contained" component="label">
                                        Upload
                                        <input hidden accept="image/*" multiple type="file" />
                                    </Button>


                                </Box>
                            </Grid>
                        </Grid>


                        <Grid container={true} item={true} xs={12} sm={12} md={6} lg={6}>
                            <Grid item xs={12} sm={12} md={3} lg={2.5} mt={1.5}>
                                <Box>
                                    <InputLabel component="proglabel" style={{ fontWeight: "bold" }}>
                                        6. AFTER PHOTO<Typography component="span1"  > * </Typography>:
                                    </InputLabel>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={12} md={8} lg={8} mt={1}>
                                <Box>

                                    <Button variant="contained" component="label">
                                        Upload
                                        <input hidden accept="image/*" multiple type="file" />
                                    </Button>


                                </Box>
                            </Grid>
                        </Grid>
                    </Grid>

                    <Grid container={true} item={true} xs={12} sm={12} md={12} lg={12} textAlign="left" >
                        <Grid item xs={12} sm={12} md={3} lg={2.5} mt={1.5} >
                            <Box>
                                <InputLabel component="proglabel" style={{ fontWeight: "bold" }}>
                                    7. UPLOAD PPTx<Typography component="span1"  > * </Typography>:
                                </InputLabel>
                            </Box>
                        </Grid>
                        <Grid item xs={12} sm={12} md={8} lg={8} mt={1}>
                            <Box>

                                <Button variant="contained" component="label">
                                    Upload
                                    <input hidden accept="image/*" multiple type="file" />
                                </Button>


                            </Box>
                        </Grid>
                    </Grid>

                    <Grid container={true} item={true} xs={12} sm={12} md={12} lg={12} mt={3}>
                        <Grid container mt={1}>
                            <Grid container={true} item={true} xs={12} sm={12} md={12} lg={12}
                            >
                                <Grid item xs={12} sm={12} md={3} lg={2.5} mt={1} textAlign="left">
                                    <Box>
                                        <InputLabel component="proglabel" style={{ fontWeight: "bold" }} >
                                            8.BENEFITS AFTER IMPLEMENTATIONS<Typography component="span1"  > * </Typography>:
                                        </InputLabel>
{/* <FormHelperText style={{color:"red"}} sx={{m: 0, mt: 0.5, mb: 1}}>{formErrors.benefit}</FormHelperText> */}
                                    </Box>
                                </Grid>
                                <Grid item xs={12} sm={12} md={8} lg={8}>
                                    <Box>
                                        <TextField fullWidth maxLength={100} size="small"
  value={formValues.benefit}
  name="benefit"
  error={errors["benefit"]?true:false}
  onChange={handleChange}
  // onChange={setData("PROGRAM_NAME")}
 />
                                    </Box>
                                </Grid>
                            </Grid>
                        </Grid>
                        <Grid container mt={1}>
                            <Grid container={true} item={true} xs={12} sm={12} md={12} lg={12}
                            >
                                <Grid item xs={12} sm={12} md={3} lg={2.5} mt={1} textAlign="left">
                                    <Box>
                                        <InputLabel component="proglabel" style={{ fontWeight: "bold" }}>
                                            9.SCOPE & PLAN FOR HORIZONTAL DEPLOYMENT<Typography component="span1"  > * </Typography>:
                                        </InputLabel>
                                        {/* <FormHelperText style={{color:"red"}} sx={{m: 0, mt: 0.5, mb: 1}}>{formErrors.scope}</FormHelperText> */}
                                    </Box>
                                </Grid>
                                <Grid item xs={12} sm={12} md={8} lg={8}>
                                    <Box>
                                        <TextField fullWidth maxLength={100} size="small"
                                          value={formValues.scope}
                                          name="scope"
                                          error={errors["scope"]?true:false}
                                          onChange={handleChange}
                                          // onChange={setData("PROGRAM_NAME")}
                                         />
                                    

                                        
                                    </Box>
                                </Grid>
                            </Grid>
                        </Grid>

                        <Grid container={true} item sx={{ m: 0, pt: 2 }} xs={12} sm={12} md={12} lg={12}>
                        <Grid container={true} item={true} xs={12} sm={12} md={6} lg={6}>
                            <Typography sx={{pb:1}}>
                                <Typography component="span1" > * </Typography>
                                <Typography component="span"  sx={{fontSize: "1rem"}}> Required fields</Typography>
                            </Typography>
                        </Grid>
                        </Grid>


                        <Grid container={true} item={true} xs={12} sm={12} md={12} lg={12}>
                            <Grid container justifyContent="left" alignItems="left" mt={1} pl={0.5} xs={6} sm={6} md={6} lg={6}  >
                                <Button component={NavLink} to="/selectone" variant="contained">Back</Button>

                            </Grid>

                            <Grid container justifyContent="right" alignItems="right" mt={1} pr={0.5} xs={6} sm={6} md={6} lg={6}  >
                                <Button     onClick={() => { handleSubmit(); }}  variant="contained">Submit</Button>

                            </Grid>


                        </Grid>







                    </Grid>

                    


                </Item>
            </Box>
        </>
    );
}
