import * as React from 'react';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import { makeStyles } from "@mui/styles";
import {
  TextField,
  Button,
  Divider,
  Typography,
  Select,
  MenuItem,

} from "@mui/material";
import { NavLink } from "react-router-dom";
import FormControl from "@mui/material/FormControl";

import FormHelperText from '@mui/material/FormHelperText';

import InputLabel from "@mui/material/InputLabel";

import { Link } from "react-router-dom";
import Navbar from './components/Navbar';


export default function Selectprogram() {

  return (
    <>
      <Navbar name="Kaizen & QC" />
      <Box
        sx={{
          //     display: 'flex',
          //     // flexWrap: 'wrap',
          //     // '& > :not(style)': {
          //     //   m: 1,

          //     // },
          paddingTop: 20, paddingLeft: 10, paddingRight: 10
        }}
      >

        <Paper elevation={3} width={10} >


          <section className="hero-section1">




            <Grid container justifyContent="center" xs={12} sm={12} md={12} lg={12} sx={{ pt: 1, pb: 1 }}>
              <Grid item className='para2'>SELECT ONE</Grid>
            </Grid>




            <Box sx={{ width: '100%' }}>





              <Divider />
              <Grid container>
                <Grid container={true} item={true} xs={12} sm={12} md={12} lg={12}>
                  <Grid container justifyContent="center" xs={12} sm={12} md={6} lg={6} sx={{ pt: 10, pb: 5 }}>

                    <Button component={NavLink} to="/Kaizen" variant="contained" style={{ minWidth: '100px', minHeight: '50px', fontSize: '15px', fontWeight: 'bold' }}>
                      KAIZEN</Button>

                  </Grid>

                  <Divider orientation="vertical" flexItem />

                  <Grid container justifyContent="center" xs={12} sm={12} md={6} lg={5.5} sx={{ pt: 10, pb: 5 }}>


                    <Button component={NavLink} to="/Qc" variant="contained" style={{ minWidth: '100px', minHeight: '50px', fontSize: '15px', fontWeight: 'bold' }}>
                      QUALITY CIRCLE</Button>


                  </Grid>


                </Grid>

              </Grid>
            </Box>


          </section>
        </Paper>
      </Box>
    </>
  );
}
