import React, { useState } from "react";
import { makeStyles } from "@mui/styles";
import {
    TextField,
    Button,
    Stack,
    Box,
    Divider,
    Grid,
    Typography,
    Select,
    MenuItem,
    CircularProgress,
    DialogContent
} from "@mui/material";
import Navbar from './components/Navbar';
import { NavLink } from "react-router-dom";
import MaterialUIPickers from "./components/Date"
import Radio from "@mui/material/Radio";
import InputAdornment from '@mui/material/InputAdornment';
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import { DatePicker } from '@mui/lab';
import FormControl from "@mui/material/FormControl";
import { StyledEngineProvider, CssVarsProvider } from '@mui/joy/styles';
// import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
// import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import Autocomplete from '@mui/material/Autocomplete';
import { DesktopDatePicker } from '@mui/x-date-pickers/DesktopDatePicker';
import FormHelperText from '@mui/material/FormHelperText';
import AdapterDateFns from "@mui/lab/AdapterDateFns";
import LocalizationProvider from "@mui/lab/LocalizationProvider";
import InputLabel from "@mui/material/InputLabel";
import { styled } from '@mui/material/styles';
// import { useNavigate } from "react-router-dom";
import Paper from '@mui/material/Paper';
import Checkbox1 from "./components/Checkbox";

const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
    ...theme.typography.body2,
    padding: theme.spacing(1),
    textAlign: 'center',
    color: theme.palette.text.secondary,
}));
const Sbu = [
    { label: 'Operation' },
    { label: 'Mechanical Maintanencer' },
    { label: 'Electrical Maintanence' },
    { label: 'C&I Maintanence' },
    { label: 'Fdy PC' },
    { label: 'Room-1' },
    { label: 'Room-2' },

];
const department = [
    { label: 'Operation' },
    { label: 'Mechanical Maintanencer' },
    { label: 'Electrical Maintanence' },
    { label: 'C&I Maintanence' },
    { label: 'Fdy PC' },
    { label: 'Room-1' },
    { label: 'Room-2' },

];
const Section = [
    { label: 'Operation' },
    { label: 'Mechanical Maintanencer' },
    { label: 'Electrical Maintanence' },
    { label: 'C&I Maintanence' },
    { label: 'Fdy PC' },
    { label: 'Room-1' },
    { label: 'Room-2' },


];
const Category = [
    { label: 'Availability' },
    { label: 'Safety ' },
    { label: 'Quality' },
    { label: 'Cost' },
    { label: 'Volume' },
    { label: 'effeciency' },
    { label: 'Asset' },
    { label: 'Productivity' },
    { label: 'Moral' },
    { label: 'Motivation' },
];

export default function Home() {

    const { date, setDate } = useState < Date | null > (null)



    return (

        <>
            <Navbar name="QUALITY CIRCLE" />
            <Box sx={{ flexGrow: 1, mt: 5, pr: 7, pl: 7 }}>

                <Item>
<form>
                    {/* <Grid container justifyContent="center" xs={12} sm={12} md={12} lg={12} pb={1} >
    <Grid item className='para1'>KAIZEN SUMMARY SHEET</Grid>
</Grid> */}

                    {/* <Divider/> */}

                    <Grid container className="text1" xs={12} sm={12} md={12} lg={12}>

                        <Grid container={true} item={true} xs={12} sm={12} md={4} lg={4}>
                            <Grid item xs={12} sm={12} md={3} lg={3} mt={1}>
                                <Box>
                                    <Grid mt={2}>
                                        <InputLabel component="proglabel" justifyContent="center" style={{ fontWeight: "bold" }}>
                                            SBU<Typography component="span1"  > * </Typography>:
                                        </InputLabel>
                                    </Grid>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={12} md={8} lg={8} mt={1}>
                                <Box>
                                    <FormControl fullWidth>

                                        <Autocomplete
                                            disablePortal
                                            id="combo-box-demo"
                                            options={Sbu}

                                            renderInput={(params) => <TextField {...params} label="Select SBU" />}
                                        />
                                    </FormControl>
                                </Box>
                            </Grid>
                        </Grid>

                        <Grid container={true} item={true} xs={12} sm={12} md={4} lg={4}>
                            <Grid item xs={12} sm={12} md={3.5} lg={3.5} mt={1}>
                                <Box>
                                    <Grid mt={2}>
                                        <InputLabel component="proglabel" style={{ fontWeight: "bold" }} >
                                            Department<Typography component="span1"  > * </Typography>:
                                        </InputLabel>
                                    </Grid>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={12} md={8} lg={8} mt={1}>
                                <Box>
                                    <FormControl fullWidth>

                                        <Autocomplete
                                            disablePortal
                                            id="combo-box-demo"
                                            options={department}

                                            renderInput={(params) => <TextField {...params} label="Select Department" />}
                                        />
                                    </FormControl>
                                </Box>
                            </Grid>
                        </Grid>

                        <Grid container={true} item={true} xs={12} sm={12} md={4} lg={4}>
                            <Grid item xs={12} sm={12} md={3} lg={3} mt={1}>
                                <Box>
                                    <Grid mt={2}>
                                        <InputLabel component="proglabel" style={{ fontWeight: "bold" }} >
                                            Section/Area<Typography component="span1"  > * </Typography>:
                                        </InputLabel>
                                    </Grid>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={12} md={8} lg={8} mt={1}>
                                <Box>
                                    <FormControl fullWidth>

                                        <Autocomplete
                                            disablePortal
                                            id="combo-box-demo"
                                            options={Section}

                                            renderInput={(params) => <TextField {...params} label="Select Section" />}
                                        />
                                    </FormControl>
                                </Box>
                            </Grid>
                        </Grid>

                    </Grid>

                    <Grid container className="text1" xs={12} sm={12} md={12} lg={12}>

                        <Grid container={true} item={true} xs={12} sm={12} md={4} lg={4}>
                            <Grid item xs={12} sm={12} md={3} lg={3} mt={1}>
                                <Box>
                                    <Grid mt={1}>
                                        <InputLabel component="proglabel" justifyContent="center" style={{ fontWeight: "bold" }}>
                                            Name Of QC<Typography component="span1"  > * </Typography>:
                                        </InputLabel>
                                    </Grid>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={12} md={8} lg={8} mt={1}>
                                <Box>
                                    <Grid>
                                        <TextField fullWidth id="outlined-basic" size="small"
                                        />

                                    </Grid>
                                </Box>
                            </Grid>
                        </Grid>

                        <Grid container={true} item={true} xs={12} sm={12} md={4} lg={4}>
                            <Grid item xs={12} sm={12} md={3.5} lg={3.5} mt={1}>
                                <Box>
                                    <Grid mt={1}>
                                        <InputLabel component="proglabel" style={{ fontWeight: "bold" }} >
                                            Team Registration No.<Typography component="span11"  > * </Typography>:
                                        </InputLabel>
                                    </Grid>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={12} md={8} lg={8} mt={1}>
                                <Box>
                                    <Grid>
                                        <TextField fullWidth id="outlined-basic" size="small"
                                        />

                                    </Grid>
                                </Box>
                            </Grid>
                        </Grid>

                        <Grid container={true} item={true} xs={12} sm={12} md={4} lg={4}>
                            <Grid item xs={12} sm={12} md={3} lg={3} mt={1}>
                                <Box>
                                    <Grid mt={1}>
                                        <InputLabel component="proglabel" style={{ fontWeight: "bold" }} >
                                            Facilitator<Typography component="span1"  > * </Typography>:
                                        </InputLabel>
                                    </Grid>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={12} md={8} lg={8} mt={1}>
                                <Box>
                                    <Grid>
                                        <TextField fullWidth id="outlined-basic" size="small"
                                        />

                                    </Grid>
                                </Box>
                            </Grid>
                        </Grid>

                    </Grid>


                    <Grid container className="text1" xs={12} sm={12} md={12} lg={12}>

                        <Grid container={true} item={true} xs={12} sm={12} md={4} lg={4}>
                            <Grid item xs={12} sm={12} md={3} lg={3} mt={1}>
                                <Box>
                                    <Grid mt={1}>
                                        <InputLabel component="proglabel" justifyContent="center" style={{ fontWeight: "bold" }}>
                                            Coordinator<Typography component="span1"  > * </Typography>:
                                        </InputLabel>
                                    </Grid>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={12} md={8} lg={8} mt={1}>
                                <Box>
                                    <Grid>
                                        <TextField fullWidth id="outlined-basic" size="small"
                                        />

                                    </Grid>
                                </Box>
                            </Grid>
                        </Grid>

                        <Grid container={true} item={true} xs={12} sm={12} md={4} lg={4}>
                            <Grid item xs={12} sm={12} md={3.5} lg={3.5} mt={1}>
                                <Box>
                                    <Grid mt={1}>
                                        <InputLabel component="proglabel" style={{ fontWeight: "bold" }} >
                                            Leaders & Members <Typography component="span1"  > * </Typography>:
                                        </InputLabel>
                                    </Grid>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={12} md={8} lg={8} mt={1}>
                                <Box>
                                    <Grid>
                                        <TextField fullWidth id="outlined-basic" size="small"
                                        />

                                    </Grid>
                                </Box>
                            </Grid>
                        </Grid>
                        {/* 
<Grid container={true} item={true} xs={12} sm={12} md={4} lg={4}>
    <Grid item xs={12} sm={12} md={3} lg={3} mt={1}>
        <Box>
            <Grid mt={1}>
                <InputLabel component="proglabel" style={{ fontWeight: "bold" }} >
                    Team Member<Typography component="span1"  > * </Typography>:
                </InputLabel>
            </Grid>
        </Box>
    </Grid>
    <Grid item xs={12} sm={12} md={8} lg={8} mt={1}>
        <Box>
            <Grid>
                <TextField fullWidth id="outlined-basic" size="small"
                />

            </Grid>
        </Box>
    </Grid>
</Grid> */}

                    </Grid>

                    {/* <Grid container xs={12} sm={12} md={12} lg={12} mt={1} d>
                        <Grid container={true} item={true} xs={12} sm={12} md={6} lg={6}>
                            <Grid item xs={12} sm={12} md={3} lg={3} mt={1}>
                                <Box>
                                    <InputLabel component="proglabel" style={{ fontWeight: "bold" }}>
                                        Start Date<Typography component="span1"  > * </Typography>:
                                    </InputLabel>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={12} md={9} lg={9} mt={1}>
                                <Box>
                                


                                </Box>
                            </Grid>
                        </Grid>


                        <Grid container={true} item={true} xs={12} sm={12} md={6} lg={6}>
                            <Grid item xs={12} sm={12} md={3} lg={3} mt={1}>
                                <Box>
                                    <InputLabel component="proglabel" style={{ fontWeight: "bold" }} >
                                        End Date<Typography component="span1"  > * </Typography>:
                                    </InputLabel>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={12} md={9} lg={9} mt={1}>
                                <Box>
                                    <FormControl fullWidth>


                                        <LocalizationProvider dateAdapter={AdapterDateFns}>

                                            <FormHelperText sx={{ m: 0, mt: 0.5, mb: 1 }}></FormHelperText>
                                        </LocalizationProvider>


                                    </FormControl>
                                </Box>
                            </Grid>
                        </Grid>
                    </Grid> */}


                    <Grid container className="text1" xs={12} sm={12} md={12} lg={12}>

<Grid container={true} item={true} xs={12} sm={12} md={4} lg={4}>
    <Grid item xs={12} sm={12} md={3} lg={3} mt={1}>
        <Box>
            <Grid mt={1}>
                <InputLabel component="proglabel" justifyContent="center" style={{ fontWeight: "bold" }}>
                Start Date<Typography component="span1"  > * </Typography>:
                </InputLabel>
            </Grid>
        </Box>
    </Grid>
    <Grid item xs={12} sm={12} md={8} lg={8} mt={1}>
        <Box>
            <Grid>
                <TextField fullWidth id="outlined-basic" size="small"
                />

            </Grid>
        </Box>
    </Grid>
</Grid>

<Grid container={true} item={true} xs={12} sm={12} md={4} lg={4}>
    <Grid item xs={12} sm={12} md={3.5} lg={3.5} mt={1}>
        <Box>
            <Grid mt={1}>
                <InputLabel component="proglabel" style={{ fontWeight: "bold" }} >
                End Date <Typography component="span1"  > * </Typography>:
                </InputLabel>
            </Grid>
        </Box>
    </Grid>
    <Grid item xs={12} sm={12} md={8} lg={8} mt={1}>
        <Box>
            <Grid>
                <TextField fullWidth id="outlined-basic" size="small"
                />

            </Grid>
        </Box>
    </Grid>
</Grid>
{/* 
<Grid container={true} item={true} xs={12} sm={12} md={4} lg={4}>
<Grid item xs={12} sm={12} md={3} lg={3} mt={1}>
<Box>
<Grid mt={1}>
<InputLabel component="proglabel" style={{ fontWeight: "bold" }} >
Team Member<Typography component="span1"  > * </Typography>:
</InputLabel>
</Grid>
</Box>
</Grid>
<Grid item xs={12} sm={12} md={8} lg={8} mt={1}>
<Box>
<Grid>
<TextField fullWidth id="outlined-basic" size="small"
/>

</Grid>
</Box>
</Grid>
</Grid> */}

</Grid>



                    <Grid container={true} item={true} xs={12} sm={12} md={12} lg={12} >
                        <Grid container mt={2}>
                            <Grid container={true} item={true} xs={12} sm={12} md={12} lg={12}
                            >
                                <Grid item xs={12} sm={12} md={3} lg={2.5} mt={1} textAlign="left">
                                    <Box>
                                        <InputLabel component="proglabel" style={{ fontWeight: "bold" }}>
                                            1.Problem Identified<Typography component="span1"  > * </Typography>:
                                        </InputLabel>
                                    </Box>
                                </Grid>
                                <Grid item xs={12} sm={12} md={8.4} lg={8.4}>
                                    <Box>
                                        <TextField fullWidth maxLength={100} size="small"

                                        />
                                    </Box>
                                </Grid>
                            </Grid>
                        </Grid>

                        <Grid container mt={1}>
                            <Grid container={true} item={true} xs={12} sm={12} md={12} lg={12}
                            >
                                <Grid item xs={12} sm={12} md={3} lg={2.5} mt={1} textAlign="left">
                                    <Box>
                                        <InputLabel component="proglabel" style={{ fontWeight: "bold" }}>
                                            3.Project Title<Typography component="span1"  > * </Typography>:
                                        </InputLabel>
                                    </Box>
                                </Grid>
                                <Grid item xs={12} sm={12} md={8.4} lg={8.4}>
                                    <Box>
                                        <TextField fullWidth maxLength={100} size="small"

                                        />
                                    </Box>
                                </Grid>
                            </Grid>
                        </Grid>


                        <Grid container mt={1}>
                            <Grid container={true} item={true} xs={12} sm={12} md={12} lg={12}
                            >
                                <Grid item xs={12} sm={12} md={3} lg={2.5} mt={1} textAlign="left">
                                    <Box>
                                        <InputLabel component="proglabel" style={{ fontWeight: "bold" }} >
                                            2.Problem Category (A/B/C)<Typography component="span1"  > * </Typography>:
                                        </InputLabel>
                                    </Box>
                                </Grid>
                                <Grid item xs={12} sm={12} md={8.6} lg={8.6}>
                                    <Box>

                                        <RadioGroup
                                            row
                                            aria-labelledby="demo-row-radio-buttons-group-label"
                                            name="row-radio-buttons-group"
                                            color="blue"
                                        >
                                            <FormControlLabel value="A" control={<Radio />} label="A (Problem solved by the team itself.)" />
                                            <FormControlLabel value="B" control={<Radio />} label="B (Problem solved with the Involvement external agencies/ other departments.)" />
                                            <FormControlLabel value="C" control={<Radio />} label="C (Problem solved with the involvement of Finance department.)" />

                                        </RadioGroup>
                                    </Box>
                                </Grid>
                            </Grid>
                        </Grid>

                        <Grid container mt={1}>
                            <Grid container={true} item={true} xs={12} sm={12} md={12} lg={12}
                            >
                                <Grid item xs={12} sm={12} md={3} lg={2.5} mt={1} textAlign="left">
                                    <Box>
                                        <InputLabel component="proglabel" style={{ fontWeight: "bold" }}>
                                            3.Projet Category<Typography component="span1"  > * </Typography>:
                                        </InputLabel>
                                    </Box>
                                </Grid>
                                <Grid item xs={12} sm={12} md={8.4} lg={8.4}>
                                    <Box>
                                    <FormControl fullWidth>

                                         <Autocomplete
                                              disablePortal
                                              id="combo-box-demo"
                                              options={Category}
                                              renderInput={(params) => <TextField {...params} label="Projet Category" />}/>
                                   </FormControl>
                                    </Box>
                                </Grid>
                            </Grid>
                        </Grid>

                        <Grid container xs={12} sm={12} md={12} lg={12} mt={1} >
                            <Grid container={true} item={true} xs={12} sm={12} md={6} lg={6}>
                                <Grid item xs={12} sm={12} md={4} lg={4.4} mt={2} textAlign="left" mr={4}>
                                    <Box>
                                        <InputLabel component="proglabel" style={{ fontWeight: "bold" }}>
                                            3. KPI Name:<Typography component="span1"  > * </Typography>:
                                        </InputLabel>
                                    </Box>
                                </Grid>
                                <Grid item xs={12} sm={12} md={6} lg={6} mt={1}>
                                    <Box>

                                        <TextField fullWidth maxLength={100} size="small"

                                        />


                                    </Box>
                                </Grid>
                            </Grid>


                            <Grid container={true} item={true} xs={12} sm={12} md={6} lg={6}>
                                <Grid item xs={12} sm={12} md={3.8} lg={3.8} mt={2} textAlign="left" pr={1}>
                                    <Box>
                                        <InputLabel component="proglabel" style={{ fontWeight: "bold" }}>
                                            4.KPI Unit<Typography component="span1"  > * </Typography>:
                                        </InputLabel>
                                    </Box>
                                </Grid>
                                <Grid item xs={12} sm={12} md={6.5} lg={6} mt={1}>
                                    <Box>

                                        <TextField fullWidth maxLength={100} size="small"

                                        />


                                    </Box>
                                </Grid>
                            </Grid>
                        </Grid>











                        <Grid container xs={12} sm={12} md={12} lg={12} mt={1} >
                            <Grid container={true} item={true} xs={12} sm={12} md={6} lg={6}>
                                <Grid item xs={12} sm={12} md={4} lg={4.4} mt={1.5} textAlign="left" mr={4}>
                                    <Box>
                                        <InputLabel component="proglabel" style={{ fontWeight: "bold" }}>
                                            4.  Baseline value with Unit<Typography component="span1"  > * </Typography>:
                                        </InputLabel>
                                    </Box>
                                </Grid>
                                <Grid item xs={12} sm={12} md={6} lg={6} mt={1}>
                                    <Box>

                                        <TextField fullWidth maxLength={100} size="small"

                                        />


                                    </Box>
                                </Grid>
                            </Grid>


                            <Grid container={true} item={true} xs={12} sm={12} md={6} lg={6}>
                                <Grid item xs={12} sm={12} md={3.8} lg={3.8} mt={2} textAlign="left" pr={1} >
                                    <Box>
                                        <InputLabel component="proglabel" style={{ fontWeight: "bold" }}>
                                            5.Achieved value with Unit<Typography component="span1"  > * </Typography>:
                                        </InputLabel>
                                    </Box>
                                </Grid>
                                <Grid item xs={12} sm={12} md={6.5} lg={6} mt={1}>
                                    <Box>

                                        <TextField fullWidth maxLength={100} size="small"

                                        />


                                    </Box>
                                </Grid>
                            </Grid>
                        </Grid>

                        <Grid container xs={12} sm={12} md={12} lg={12} mt={1} >
                            <Grid container={true} item={true} xs={12} sm={12} md={6} lg={6}>
                                <Grid item xs={12} sm={12} md={4} lg={4.4} mt={1.5} textAlign="left" mr={4}>
                                    <Box>
                                        <InputLabel component="proglabel" style={{ fontWeight: "bold" }}>
                                            6. Root Cause/s Identified<Typography component="span1"  > * </Typography>:
                                        </InputLabel>
                                    </Box>
                                </Grid>
                                <Grid item xs={12} sm={12} md={6} lg={6} mt={1}>
                                    <Box>

                                        <TextField fullWidth maxLength={100} size="small"

                                        />


                                    </Box>
                                </Grid>
                            </Grid>


                            <Grid container={true} item={true} xs={12} sm={12} md={6} lg={6}>
                                <Grid item xs={12} sm={12} md={3.8} lg={3.8} mt={2} textAlign="left" pr={1} >
                                    <Box>
                                        <InputLabel component="proglabel" style={{ fontWeight: "bold" }}>
                                            7.Solution Developed<Typography component="span1"  > * </Typography>:
                                        </InputLabel>
                                    </Box>
                                </Grid>
                                <Grid item xs={12} sm={12} md={6.5} lg={6} mt={1}>
                                    <Box>

                                        <TextField fullWidth maxLength={100} size="small"

                                        />


                                    </Box>
                                </Grid>
                            </Grid>
                        </Grid>

                        <Grid container xs={12} sm={12} md={12} lg={12} mt={1} >
                            <Grid container={true} item={true} xs={12} sm={12} md={6} lg={6}>
                                <Grid item xs={12} sm={12} md={4} lg={4.4} mt={1.5} textAlign="left" mr={4}>
                                    <Box>
                                        <InputLabel component="proglabel" style={{ fontWeight: "bold" }}>
                                        Tools used at problem stage<Typography component="span1"  > * </Typography>:
                                        </InputLabel>
                                    </Box>
                                </Grid>
                                <Grid item xs={12} sm={12} md={6} lg={6} mt={1}>
                                    <Box>

                                        <TextField fullWidth maxLength={100} size="small"

                                        />


                                    </Box>
                                </Grid>
                            </Grid>


                            <Grid container={true} item={true} xs={12} sm={12} md={6} lg={6}>
                                <Grid item xs={12} sm={12} md={3.8} lg={3.8} mt={2} textAlign="left" pr={1} >
                                    <Box>
                                        <InputLabel component="proglabel" style={{ fontWeight: "bold" }}>
                                        Tools used for developing solutions<Typography component="span1"  > * </Typography>:
                                        </InputLabel>
                                    </Box>
                                </Grid>
                                <Grid item xs={12} sm={12} md={6.5} lg={6} mt={1}>
                                    <Box>

                                        <TextField fullWidth maxLength={100} size="small"

                                        />


                                    </Box>
                                </Grid>
                            </Grid>
                        </Grid>




                        <Grid container className="text1" xs={12} sm={12} md={12} lg={12}>

<Grid container={true} item={true} xs={12} sm={12} md={4} lg={4}>
    <Grid item xs={12} sm={12} md={4} lg={4} mt={1}>
        <Box>
            <Grid mt={1}>
                <InputLabel component="proglabel" justifyContent="center" style={{ fontWeight: "bold" }}>
                8.Trends/Images-Before<Typography component="span1"  > * </Typography>:
                </InputLabel>
            </Grid>
        </Box>
    </Grid>
    <Grid item xs={12} sm={12} md={8} lg={8} mt={1} pl={4}>
        <Box>
        <Button variant="contained" component="label">
                                        Upload
                                        <input hidden accept="image/*" multiple type="file" />
                                    </Button>
        </Box>
    </Grid>
</Grid>

<Grid container={true} item={true} xs={12} sm={12} md={4} lg={4}>
    <Grid item xs={12} sm={12} md={3.5} lg={3.5} mt={1}>
        <Box>
            <Grid mt={1}>
                <InputLabel component="proglabel" style={{ fontWeight: "bold" }} >
                9.Trends/Images-After<Typography component="span11"  > * </Typography>:
                </InputLabel>
            </Grid>
        </Box>
    </Grid>
    <Grid item xs={12} sm={12} md={8} lg={8} mt={1}>
        <Box>
        <Button variant="contained" component="label">
                                        Upload
                                        <input hidden accept="image/*" multiple type="file" />
                                    </Button>
        </Box>
    </Grid>
</Grid>

<Grid container={true} item={true} xs={12} sm={12} md={4} lg={4}>
    <Grid item xs={12} sm={12} md={3} lg={3} mt={1}>
        <Box>
            <Grid mt={1}>
                <InputLabel component="proglabel" style={{ fontWeight: "bold" }} >
               Upload PPTx<Typography component="span1"  > * </Typography>:
                </InputLabel>
            </Grid>
        </Box>
    </Grid>
    <Grid item xs={12} sm={12} md={8} lg={8} mt={1}  pl={6}>
        <Box>
        <Button variant="contained" component="label">
                                        Upload
                                        <input hidden accept="image/*" multiple type="file" />
                                    </Button>
        </Box>
    </Grid>
</Grid>

</Grid>




                        {/* <Grid container={true} item={true} xs={12} sm={12} md={12} lg={12} textAlign="left" >
                            <Grid item xs={12} sm={12} md={3} lg={2.5} mt={1.5} >
                                <Box>
                                    <InputLabel component="proglabel" style={{ fontWeight: "bold" }}>
                                        4.  Baseline value with Unit<Typography component="span1"  > * </Typography>:
                                    </InputLabel>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={12} md={8} lg={8} mt={1}>
                                <Box>
                                    <TextField fullWidth maxLength={100} size="small" />
                                </Box>
                            </Grid>
                        </Grid>
                        <Grid container={true} item={true} xs={12} sm={12} md={12} lg={12} textAlign="left" >
                            <Grid item xs={12} sm={12} md={3} lg={2.5} mt={1.5} >
                                <Box>
                                    <InputLabel component="proglabel" style={{ fontWeight: "bold" }}>
                                        5.Achieved value with Unit<Typography component="span1"  > * </Typography>:
                                    </InputLabel>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={12} md={8} lg={8} mt={1}>
                                <Box>
                                    <TextField fullWidth maxLength={100} size="small" />
                                </Box>
                            </Grid>
                        </Grid> */}








                        {/* <Grid container mt={1}>
                            <Grid container={true} item={true} xs={12} sm={12} md={12} lg={12}
                            >
                                <Grid item xs={12} sm={12} md={3} lg={2.5} mt={1} textAlign="left" >
                                    <Box>
                                        <InputLabel component="proglabel" style={{ fontWeight: "bold" }}>
                                            6. Root Cause/s Identified (Why-Why Analysis)<Typography component="span1"  > * </Typography>:
                                        </InputLabel>
                                    </Box>
                                </Grid>
                                <Grid item xs={12} sm={12} md={8} lg={8}>
                                    <Box>
                                        <TextField fullWidth maxLength={100} size="small"

                                        />
                                    </Box>
                                </Grid>
                            </Grid>
                        </Grid> */}

                        {/* <Grid container mt={1}>
                            <Grid container={true} item={true} xs={12} sm={12} md={12} lg={12}
                            >
                                <Grid item xs={12} sm={12} md={3} lg={2.5} mt={1} textAlign="left" >
                                    <Box>
                                        <InputLabel component="proglabel" style={{ fontWeight: "bold" }}>
                                            7.Solution Developed<Typography component="span1"  > * </Typography>:
                                        </InputLabel>
                                    </Box>
                                </Grid>
                                <Grid item xs={12} sm={12} md={8} lg={8}>
                                    <Box>
                                        <TextField fullWidth maxLength={100} size="small"

                                        />
                                    </Box>
                                </Grid>
                            </Grid>
                        </Grid> */}




                    </Grid>


                    {/* <Grid container xs={12} sm={12} md={12} lg={12} mt={1} >
                        <Grid container={true} item={true} xs={12} sm={12} md={6} lg={6}>
                            <Grid item xs={12} sm={12} md={4} lg={3.5} mt={1.5} textAlign="left" mr={4}>
                                <Box>
                                    <InputLabel component="proglabel" style={{ fontWeight: "bold" }}>
                                        8.Trends/Images-Before<Typography component="span1"  > * </Typography>:
                                    </InputLabel>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={12} md={3} lg={3} mt={1}>
                                <Box>

                                    <Button variant="contained" component="label">
                                        Upload
                                        <input hidden accept="image/*" multiple type="file" />
                                    </Button>


                                </Box>
                            </Grid>
                        </Grid>


                        <Grid container={true} item={true} xs={12} sm={12} md={6} lg={6}>
                            <Grid item xs={12} sm={12} md={3} lg={2.5} mt={2} textAlign="left" pr={1} >
                                <Box>
                                    <InputLabel component="proglabel" style={{ fontWeight: "bold" }}>
                                        9.Trends/Images-After<Typography component="span1"  > * </Typography>:
                                    </InputLabel>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={12} md={8} lg={8} mt={1}>
                                <Box>

                                    <Button variant="contained" component="label">
                                        Upload
                                        <input hidden accept="image/*" multiple type="file" />
                                    </Button>


                                </Box>
                            </Grid>
                        </Grid>
                    </Grid>

                    <Grid container={true} item={true} xs={12} sm={12} md={12} lg={12} textAlign="left" >
                        <Grid item xs={12} sm={12} md={3} lg={2.5} mt={1.5} >
                            <Box>
                                <InputLabel component="proglabel" style={{ fontWeight: "bold" }}>
                                    7. UPLOAD PPTx<Typography component="span1"  > * </Typography>:
                                </InputLabel>
                            </Box>
                        </Grid>
                        <Grid item xs={12} sm={12} md={8} lg={8} mt={1}>
                            <Box>

                                <Button variant="contained" component="label">
                                    Upload
                                    <input hidden accept="image/*" multiple type="file" />
                                </Button>


                            </Box>
                        </Grid>
                    </Grid> */}

                    {/* <Grid container xs={12} sm={12} md={12} lg={12} mt={1} >
                        <Grid container={true} item={true} xs={12} sm={12} md={6} lg={5.5}>
                            <Grid item xs={12} sm={12} md={4} lg={4.8} mt={1.5} textAlign="left" mr={4}>
                                <Box>
                                    <InputLabel component="proglabel" style={{ fontWeight: "bold" }}>
                                        Tools used at problem stage<Typography component="span1"  > * </Typography>:
                                    </InputLabel>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={12} md={6} lg={6} mt={1}>
                                <Box>

                                    <TextField fullWidth maxLength={100} size="small"

                                    />


                                </Box>
                            </Grid>
                        </Grid>


                        <Grid container={true} item={true} xs={12} sm={12} md={6} lg={6.5}>
                            <Grid item xs={12} sm={12} md={3.8} lg={3.8} mt={1.5} >
                                <Box>
                                    <InputLabel component="proglabel" style={{ fontWeight: "bold" }}>
                                        Tools used for developing solutions<Typography component="span1"  > * </Typography>:
                                    </InputLabel>
                                </Box>
                            </Grid>
                            <Grid item xs={12} sm={12} md={5} lg={5.2} mt={1}>
                                <Box>

                                    <TextField fullWidth maxLength={100} size="small"

                                    />


                                </Box>
                            </Grid>
                        </Grid>
                    </Grid> */}






                    <Grid container={true} item={true} xs={12} sm={12} md={12} lg={12} mt={1}>
                        {/* <Grid container mt={1}>
                            <Grid container={true} item={true} xs={12} sm={12} md={12} lg={12}
                            >
                                <Grid item xs={12} sm={12} md={3} lg={2.5} mt={1} textAlign="left">
                                    <Box>
                                        <InputLabel component="proglabel" style={{ fontWeight: "bold" }} >
                                            Tools used at problem stage<Typography component="span1"  > * </Typography>:
                                        </InputLabel>
                                    </Box>
                                </Grid>
                                <Grid item xs={12} sm={12} md={8} lg={8}>
                                    <Box>
                                        <TextField fullWidth maxLength={100} size="small"

                                        />
                                    </Box>
                                </Grid>
                            </Grid>
                        </Grid> */}
                        {/* <Grid container mt={1}>
                            <Grid container={true} item={true} xs={12} sm={12} md={12} lg={12}
                            >
                                <Grid item xs={12} sm={12} md={3} lg={2.5} mt={1} textAlign="left">
                                    <Box>
                                        <InputLabel component="proglabel" style={{ fontWeight: "bold" }}>
                                            Tools used for developing solutions<Typography component="span1"  > * </Typography>:
                                        </InputLabel>
                                    </Box>
                                </Grid>
                                <Grid item xs={12} sm={12} md={8} lg={8}>
                                    <Box>
                                        <TextField fullWidth maxLength={100} size="small"

                                        />
                                    </Box>
                                </Grid>
                            </Grid>
                        </Grid> */}

<Grid container className="text1" xs={12} sm={12} md={12} lg={12}>

<Grid container={true} item={true} xs={12} sm={12} md={4} lg={4}>
    <Grid item xs={12} sm={12} md={3} lg={3} mt={1}>
        <Box>
            <Grid mt={1}>
                <InputLabel component="proglabel" justifyContent="center" style={{ fontWeight: "bold" }}>
                Tangible benefits:<Typography component="span1"  > * </Typography>:
                </InputLabel>
            </Grid>
        </Box>
    </Grid>
    <Grid item xs={12} sm={12} md={8} lg={8} mt={1}>
        <Box>
            <Grid>
                <TextField fullWidth id="outlined-basic" size="small"
                />

            </Grid>
        </Box>
    </Grid>
</Grid>

<Grid container={true} item={true} xs={12} sm={12} md={4} lg={4}>
    <Grid item xs={12} sm={12} md={3.5} lg={3.5} mt={1}>
        <Box>
            <Grid mt={1}>
                <InputLabel component="proglabel" style={{ fontWeight: "bold" }} >
                Intangible benefits:<Typography component="span11"  > * </Typography>:
                </InputLabel>
            </Grid>
        </Box>
    </Grid>
    <Grid item xs={12} sm={12} md={8} lg={8} mt={1}>
        <Box>
            <Grid>
                <TextField  fullWidth id="outlined-basic" size="small"
                />

            </Grid>
        </Box>
    </Grid>
</Grid>

<Grid container={true} item={true} xs={12} sm={12} md={4} lg={4}>
    <Grid item xs={12} sm={12} md={3} lg={3} mt={1}>
        <Box>
            <Grid mt={1}>
                <InputLabel component="proglabel" style={{ fontWeight: "bold" }} >
                Savings per Annum<Typography component="span1"  > * </Typography>:
                </InputLabel>
            </Grid>
        </Box>
    </Grid>
    <Grid item xs={12} sm={12} md={8} lg={8} mt={1}>
        <Box>
            <Grid>
                <TextField fullWidth id="outlined-basic" size="small"
                startAdornment={<InputAdornment position="start">RS.</InputAdornment>}
                />
            </Grid>
        </Box>
    </Grid>
</Grid>

</Grid>


                        {/* <Grid container >
                            <Grid container={true} item={true} xs={12} sm={12} md={12} lg={12}
                            >
                                <Grid item xs={12} sm={12} md={3} lg={2.5} textAlign="left">
                                    <Box>
                                        <InputLabel component="proglabel" style={{ fontWeight: "bold" }}>
                                            Savings per Annum in Rs.	<Typography component="span1"  > * </Typography>:
                                        </InputLabel>
                                    </Box>
                                </Grid>
                                <Grid item xs={12} sm={12} md={8.4} lg={8.4}>
                                    <Box>
                                        <TextField fullWidth maxLength={100} size="small"

                                        />
                                    </Box>
                                </Grid>
                            </Grid>
                        </Grid> */}
 <Grid container={true} item sx={{ m: 0, pt: 1 }} xs={12} sm={12} md={12} lg={12}>
                        <Grid container={true} item={true} xs={12} sm={12} md={6} lg={6}>
                            <Typography >
                                <Typography component="span1" > * </Typography>
                                <Typography component="span"  sx={{fontSize: "1rem"}}> Required fields</Typography>
                            </Typography>
                        </Grid>
                        </Grid>

                        <Grid container={true} item={true} xs={12} sm={12} md={12} lg={12}>
                            <Grid container justifyContent="left" alignItems="left" mt={1} pl={0.5} xs={6} sm={6} md={6} lg={6}  >
                                <Button component={NavLink} to="/selectone" variant="contained">Back</Button>

                            </Grid>

                            <Grid container justifyContent="right" alignItems="right" mt={1} pr={0.5} xs={6} sm={6} md={6} lg={6}  >
                                <Button  component={NavLink} to="/Formsubmit" variant="contained">Submit</Button>

                            </Grid>


                        </Grid>


                    </Grid>



                    </form>
                </Item>
            </Box>
        </>
    );
}
