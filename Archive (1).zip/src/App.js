
import './App.css';
import Home from './Home';
import Home1 from './Home1';
import logo from './back.png'; 
import React, { Component }  from 'react';
import Main from './Main';
import background from './images/background2.jpg';
import GlassCard from './glasscard';
import Navbar from './components/Navbar';
import { Divider, Grid, Box, Link, Typography } from "@mui/material";
import Selectprogram from './Selectprogram';
import Formsubmit from './components/Formsubmit';
import Form from './Form';
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

function App() {
  return (<>
   {/* <Navbar/> */}

  <div className='background'>



<Router>
        <Routes>
          <Route path="/" element={ <GlassCard />} />
          <Route path="/Selectone" element={<Selectprogram/> } />
          <Route path="/Kaizen" element={<Home1 />} />
          <Route path="/Qc" element={<Home />} />
          <Route path="/form" element={<Form/>} />
          <Route path="/Formsubmit" element={<Formsubmit />} />
        </Routes>
      </Router>




 {/* <Selectprogram/> */}
   {/* <Home/> */}
   {/* <Home1/> */}
   </div>
   </>
  );
}

export default App;
