import React from 'react';
// import profile from './images/logo.png';
import styled from 'styled-components';
import { useSpring, animated, config } from 'react-spring';
import Navbar from './components/Navbar';
import { Link, NavLink, useNavigate } from "react-router-dom";
import {
    TextField,
    Button,
    Box,
    Divider,
    Grid,
    Typography,
    Select,
    MenuItem,
    CircularProgress,
    DialogContent,
    deprecatedPropType
} from "@mui/material";
import InputLabel from "@mui/material/InputLabel";

// import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
// import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
// import { DatePicker } from '@mui/x-date-pickers/DatePicker';
// const initialValues = { username: "", email: "", password: "" };
//   const [formValues, setFormValues] = useState(initialValues);



// const [value, setValue] = React.useState(null);


const Form = () => {

    return (

        <>
            <Navbar name="Kaizen & QC" />
            <div className="App"
                style={{
                    marginTop: '18rem',
                    backgroundPosition: 'center',
                    backgroundSize: 'cover',
                    backgroundRepeat: 'no-repeat',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    textAlign: 'center'

                }}
            >
                <Grid container className="text1" xs={12} sm={12} md={12} lg={12}>

                    <Grid container={true} item={true} xs={12} sm={12} md={4} lg={4}>
                        <Grid item xs={12} sm={12} md={3} lg={3} mt={1}>
                            <Box>
                                <Grid mt={1}>
                                    <InputLabel component="proglabel" justifyContent="center" style={{ fontWeight: "bold" }}>
                                        Team Name<Typography component="span1"  > * </Typography>:
                                    </InputLabel>
                                 

                                </Grid>
                            </Box>
                        </Grid>
                        <Grid item xs={12} sm={12} md={8} lg={8} mt={1}>
                            <Box>
                                <Grid>
                                    <TextField fullWidth id="outlined-basic" size="small" 
                                    
                                    
                                    />


                                </Grid>
                            </Box>
                        </Grid>
                    </Grid>

                    <Button variant="contained"> submit</Button>
                </Grid>

                {/* <LocalizationProvider dateAdapter={AdapterDateFns}>
      <DatePicker
        label="Basic example"
        value={value}
        onChange={(newValue) => {
          setValue(newValue);
        }}
        renderInput={(params) => <TextField {...params} />}
      />
    </LocalizationProvider> */}

            </div>
        </>
    );

}

export default Form;