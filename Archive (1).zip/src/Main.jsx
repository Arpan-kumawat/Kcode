import * as React from 'react';
import { useTheme } from '@mui/material/styles';
import Box from '@mui/material/Box';
import './Menu.css';
import Typography from '@mui/material/Typography';
import logo from './md.jpeg'; 
import Navbar from './components/Navbar';
import Grid from '@mui/material/Grid';
import Paper from '@mui/material/Paper';
import InputLabel from "@mui/material/InputLabel";
import {
  TextField,
  Button,
  Divider,


  Select,
  MenuItem,
  CircularProgress,
  DialogContent
} from "@mui/material";
export default function Menu() {
  const theme = useTheme();

  return (
    <>
   
<Box
      sx={{
    //     display: 'flex',
    //     // flexWrap: 'wrap',
    //     // '& > :not(style)': {
    //     //   m: 1,
        
    //     // },
    paddingTop:5, paddingLeft:3,paddingRight:3 ,minHeight:"40"}}
    >
      
      <Paper elevation={3} >  


<section className="hero-section1">
{/* <Grid container justifyContent="center" className='para1'>KAIZEN SUMMARY SHEET</Grid> */}
<Grid container justifyContent="center" xs={12} sm={12} md={12} lg={12} >
                    


                    <Grid container={true} item={true} xs={12} sm={12} md={12} lg={12}>
                        <Grid item xs={12} sm={12} md={6} lg={6} >
                            <Box>
                                <Grid mt={1}>
                                    <InputLabel component="proglabel"  >
                                        Team Name
                                    </InputLabel>
                                </Grid>
                            </Box>
                        </Grid>


                        <Grid item xs={12} sm={12} md={6} lg={6}>
                       


                        </Grid>
                    </Grid>





                </Grid>
    </section>
    </Paper>
    </Box>

    </>
  );
}
