import React from 'react';
import profile from './images/logo.png';
import styled from 'styled-components';
import { useSpring, animated, config } from 'react-spring';
import Navbar from './components/Navbar';
import { Link, NavLink, useNavigate } from "react-router-dom";
import {
    TextField,
    Button,
    Box,
    Divider,
    Grid,
    Typography,
    Select,
    MenuItem,
    CircularProgress,
    DialogContent,
    deprecatedPropType
} from "@mui/material";
import { green } from '@mui/material/colors';
const Container = styled(animated.div)`
display: inline-block;
padding: 3em;
background: #C7D2FE66;
border-radius: 10px;
z-index: 1;
height:100x;
position: relative;
backdrop-filter: blur(10px);
border: 2px solid transparent;
background-clip: border-box;
cursor: pointer;
`;

const StyledImg = styled.img`
    width: 200px;
    height: auto;
    border: 2px solid #000;
    border-radius: 50%;
`;

const StyledH1 = styled.h1`
    line-heright: 1.5;
    letter-spacing: 1.5;
    font-family: "Gilroy";
`;

const StyledH3 = styled.h3`
    line-heright: 1.5;
    letter-spacing: 1.15;
    font-family: "Gilroy";
    font-size: 20px;
`;

const calc = (x, y) => [-(y - window.innerHeight / 2) / 20, (x - window.innerWidth / 2) / 20, 1]
const trans = (x, y, s) => `perspective(600px) rotateX(${x}deg) rotateY(${y}deg) scale(${s})`
// const navigate = useNavigate();
const GlassCard = () => {
    const [props, set] = useSpring(() => ({ xys: [0, 0, 1], config: config.default }))
    return (

        <>
            <Navbar name="Kaizen & QC" />
            <div className="App"
                style={{
                    marginTop: '18rem',
                    backgroundPosition: 'center',
                    backgroundSize: 'cover',
                    backgroundRepeat: 'no-repeat',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    textAlign: 'center'

                }}
            >




                <Container
                    onMouseMove={({ clientX: x, clientY: y }) => (set({ xys: calc(x, y) }))}
                    onMouseLeave={() => set({ xys: [0, 0, 1] })}
                    style={{
                        transform: props.xys.interpolate(trans), width: "55%",
                        fontStyle: 'italic',


                    }}
                >

                    <StyledH1>LET'S CHANGE FOR BETTER...</StyledH1>
                    <StyledH3>     <br />

                        Login to continue<br />


                        <Button component={NavLink} to="/Selectone" variant="contained" style={{ marginTop: "2rem" }}  >
                            Login
                        </Button>
                    </StyledH3>
                </Container>
            </div>
        </>
    );

}

export default GlassCard;