import * as React from 'react';
import Box from '@mui/joy/Box';
import Checkbox from '@mui/joy/Checkbox';
import List from '@mui/joy/List';
import ListItem from '@mui/joy/ListItem';
import Typography from '@mui/joy/Typography';
import {Grid} from "@mui/material";
export default function Checkbox1() {
  return (
    <Box >


 <Grid container={true} item={true} xs={12} sm={12} md={12} lg={12} mt={2}> 
 <Grid item xs={12} sm={12} md={2.5} lg={2.5} mt={0.5} textAlign="left">
      <Typography  component="proglabel" pr={1} style={{fontWeight: "bold"}} >
      Project Impact on :  
      </Typography>
</Grid>
<Grid item xs={12} sm={12} md={9} lg={9}>
      <Box role="group" aria-labelledby="topping">
        <List
          row
          wrap
          sx={{
            '--List-gap': '15px',
            '--List-item-radius': '10px',
          }}
        >
          {[
            'Productivity',
            'Quality',
            'Cost',
            'Delivery',
            'Safety',
            'Moral',
            'Environment',
          ].map((item, index) => (
            <ListItem key={item}>
              <Checkbox
               
                overlay
                disableIcon
                variant="soft"
                label={item}
              />
            </ListItem>
          ))}
        </List>
      </Box>
</Grid>

      </Grid>
      </Box>
     
  );
}
