import React, { useState } from "react";
import "./navbar.css";

import logo from './logo.png';

import { NavLink } from "react-router-dom";



const Navbar = (props) => {
  const [showMediaIcons, setShowMediaIcons] = useState(false);
  return (
    <>
      <nav className="main-nav">



        <div className="logo">

          {/* <img src={logo} alt="Logo" /> */}

        </div>

        <div
          className={
            showMediaIcons ? "menu-link mobile-menu-link" : "menu-link"
          }>
          <div className="logo">
            <ul>
              <h2>{props.name}</h2>
            </ul>
          </div>
        </div>


        <div className="social-media">

        </div>
      </nav>


      {/* <section className="hero-section">
        <p>Welcome to </p>
        <h1>Thapa Technical</h1>
      </section> */}
    </>
  );
};

export default Navbar;
